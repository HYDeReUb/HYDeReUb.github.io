-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2019-11-03 15:59:28
-- 伺服器版本： 10.4.6-MariaDB
-- PHP 版本： 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `ksu_database`
--
CREATE DATABASE IF NOT EXISTS `ksu_database` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ksu_database`;
-- --------------------------------------------------------

--
-- 資料表結構 `advisor_detail`
--

CREATE TABLE `advisor_detail` (
  `std_advisor` varchar(3) NOT NULL,
  `advisor_name` varchar(15) NOT NULL,
  `advisor_cell` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 傾印資料表的資料 `advisor_detail`
--

INSERT INTO `advisor_detail` (`std_advisor`, `advisor_name`, `advisor_cell`) VALUES
('T01', 'John Wick', 910123456),
('T02', 'Mary Win', 912345667),
('T03', 'Stephine Li', 12345612),
('T04', 'Mike Wang', 23441234);

-- --------------------------------------------------------

--
-- 資料表結構 `city_detail`
--

CREATE TABLE `city_detail` (
  `std_city_id` char(2) NOT NULL,
  `std_city_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 傾印資料表的資料 `city_detail`
--

INSERT INTO `city_detail` (`std_city_id`, `std_city_name`) VALUES
('A1', 'Taipei'),
('A2', 'Tainan'),
('A3', 'Kaoshiung'),
('A4', 'Taichung');

-- --------------------------------------------------------

--
-- 資料表結構 `dept_detail`
--

CREATE TABLE `dept_detail` (
  `dept_id` char(2) NOT NULL,
  `dept_name` varchar(26) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 傾印資料表的資料 `dept_detail`
--

INSERT INTO `dept_detail` (`dept_id`, `dept_name`) VALUES
('IE', 'Information Engineer'),
('IM', 'Information Management'),
('ME', 'Mechanic Engineering');

-- --------------------------------------------------------

--
-- 資料表結構 `ksu_std_table`
--

CREATE TABLE `ksu_std_table` (
  `ksu_std_id` varchar(6) NOT NULL,
  `ksu_std_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ksu_std_age` int(2) NOT NULL,
  `ksu_std_department` char(2) NOT NULL,
  `ksu_std_signin` int(4) NOT NULL,
  `ksu_std_grade` int(1) NOT NULL DEFAULT 100
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 資料表結構 `store_information`
--

CREATE TABLE `store_information` (
  `Store_Name` varchar(12) NOT NULL,
  `Sales` int(1) NOT NULL,
  `Txn_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 傾印資料表的資料 `store_information`
--

INSERT INTO `store_information` (`Store_Name`, `Sales`, `Txn_Date`) VALUES
('Los Angeles', 1500, '2019-10-05'),
('San Diego', 250, '2019-10-07'),
('Los Angeles', 300, '2019-10-08'),
('Boston', 700, '2019-10-08');

-- --------------------------------------------------------

--
-- 資料表結構 `student_detail`
--

CREATE TABLE `student_detail` (
  `std_id` char(8) NOT NULL,
  `std_name` varchar(10) NOT NULL,
  `std_city_id` char(2) NOT NULL,
  `std_cell` int(10) NOT NULL,
  `std_address` varchar(30) NOT NULL,
  `dept_id` char(2) NOT NULL,
  `std_grade` int(1) NOT NULL,
  `std_advisor` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 傾印資料表的資料 `student_detail`
--

INSERT INTO `student_detail` (`std_id`, `std_name`, `std_city_id`, `std_cell`, `std_address`, `dept_id`, `std_grade`, `std_advisor`) VALUES
('4070E001', 'John Mike', 'A1', 910971234, 'skyline Dr. no. 120', 'IE', 90, 'T01'),
('4070E002', 'Wom  Try', 'A2', 91029123, 'station Dr. no. 11', 'IE', 45, 'T01'),
('4070E003', 'Mike Fire', 'A1', 912123456, 'Fire Street no 11.', 'IM', 60, 'T02'),
('4070E004', 'Dave Van', 'A3', 901233333, 'Make Street no. 22', 'ME', 77, 'T03'),
('4070E005', 'Mike Wu', 'A1', 91198987, 'Fire Dr. no 25', 'IE', 88, 'T01'),
('4070E006', 'Wuber Eat', 'A2', 92298765, 'Fire Dr. no 27', 'IM', 55, 'T02'),
('4070E007', 'Mike Wu', 'A2', 91198983, 'Water Dr. no 25', 'IE', 22, 'T01'),
('4070E008', 'Wuber Eat', 'A3', 92298753, 'Fire Dr. no 27', 'IE', 99, 'T01');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `advisor_detail`
--
ALTER TABLE `advisor_detail`
  ADD PRIMARY KEY (`std_advisor`);

--
-- 資料表索引 `dept_detail`
--
ALTER TABLE `dept_detail`
  ADD PRIMARY KEY (`dept_id`);

--
-- 資料表索引 `ksu_std_table`
--
ALTER TABLE `ksu_std_table`
  ADD PRIMARY KEY (`ksu_std_id`);

--
-- 資料表索引 `student_detail`
--
ALTER TABLE `student_detail`
  ADD UNIQUE KEY `std_pk` (`std_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
