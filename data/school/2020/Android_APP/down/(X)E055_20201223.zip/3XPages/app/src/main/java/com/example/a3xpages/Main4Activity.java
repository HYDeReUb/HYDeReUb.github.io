package com.example.a3xpages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

public class Main4Activity extends AppCompatActivity {
    String[] companyNames;
    String[] companyURLs;
    LinearLayout linearLayout;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        listView = new ListView(this);
        Intent intent = getIntent();
        int sty = intent.getIntExtra("style_img",0);

        int[] style = {
                android.R.layout.simple_list_item_1,
                   android.R.layout.simple_list_item_single_choice,
                android.R.layout.simple_list_item_multiple_choice,
                android.R.layout.simple_list_item_checked,
                android.R.layout.simple_list_item_2
        };
        companyNames = getResources().getStringArray(R.array.companyName);
        companyURLs = getResources().getStringArray(R.array.companyURL);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, style[sty], companyNames);
        listView.setAdapter(adapter);

        linearLayout.addView(listView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,0,1));

        setContentView(linearLayout);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(Main4Activity.this, Main3Activity.class);
                intent.putExtra("companyName", companyNames[position]);
                intent.putExtra("companyURL", companyURLs[position]);
                startActivity(intent);
            }
        });

    }

}