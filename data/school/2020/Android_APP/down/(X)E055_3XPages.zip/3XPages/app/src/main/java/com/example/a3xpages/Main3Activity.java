package com.example.a3xpages;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Main3Activity extends AppCompatActivity {

    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        webview = (WebView)findViewById(R.id.companyWebView);
        webview.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webview.getSettings();
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(true);

        String companyName_s = getIntent().getStringExtra("companyName");
        String companyURL_s = getIntent().getStringExtra("companyURL");
        getSupportActionBar().setTitle(companyName_s);
        webview.loadUrl(companyURL_s);

    }
}