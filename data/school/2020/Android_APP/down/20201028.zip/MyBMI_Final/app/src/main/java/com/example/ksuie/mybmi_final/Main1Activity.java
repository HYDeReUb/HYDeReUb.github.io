package com.example.ksuie.mybmi_final;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main1Activity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1_main);
        setTitle("Report Page");

        Bundle bundle = getIntent().getExtras();

        String bmi = bundle.getString()

        Button btn_to_page1 = (Button) findViewById(R.id.button10);

        btn_to_page1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent();
                intent.setClass(Main1Activity.this, MainActivity.class);

                Bundle bundle = new Bundle();

                EditText height = findViewById(R.id.height);
                EditText weight = findViewById(R.id.weight);

                String height_s = height.getText().toString();
                String weight_s = weight.getText().toString();
                double height_d = Double.parseDouble(height_s);
                double weight_d = Double.parseDouble(weight_s);

                double bmi_result = weight_d / ((height_d / 100) * (height_d / 100));

                EditText name = findViewById(R.id.InputText);
                String name_s = name.getText().toString();
                bundle.putString("key1", name_s + "BMI = "+ df.format(bmi_result));

                intent.putExtras(bundle);

                startActivity(intent);
            }
        });
    }

}
