package com.example.mycurrency;

public class MyListElement {
    private int countryIcon;
    private String currencyKeyLoad;

    public String getCurrencyValue() {
        return currencyValue;
    }

    public void setCurrencyValue(String currencyValue) {
        this.currencyValue = currencyValue;
    }

    private String currencyValue;
    public int getCountryIcon() {
        return countryIcon;
    }

    public void setCountryIcon(int countryIcon) {
        this.countryIcon = countryIcon;
    }

    public String getCurrencyKeyLoad() {
        return currencyKeyLoad;
    }

    public void setCurrencyKeyLoad(String currencyKeyLoad) {
        this.currencyKeyLoad = currencyKeyLoad;
    }


}
