package com.example.mycurrency;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    DecimalFormat df = new DecimalFormat("#.##");
    private double input_value;
    private double currency_USD;
    private double currency_GBP;
    private double currency_CAD;
    private double currency_KRW;
    private double currency_JPY;
    String[] currencyKeyLoad;
    String[] currencyValue = new String[5];
    LinearLayout linearLayout;
    ListView listView;
    ArrayList<String> currencyKeyReadList;
    ArrayList<MyListElement> elementList = new ArrayList<MyListElement>();
    MyListAdapter myListAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
       boolean done = getCurrencyFromBOT();
        linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        listView = new ListView(this);
        currencyKeyLoad = getResources().getStringArray(R.array.currencyKeyLoad);
        for(int i = 0; i < currencyKeyLoad.length; i++){
            MyListElement element = new MyListElement();
            element.setCurrencyKeyLoad(currencyKeyLoad[i]);
            element.setCurrencyValue(currencyValue[i]);
            element.setCountryIcon(android.R.drawable.btn_star_big_on);
            elementList.add(element);
        }
        myListAdapter = new MyListAdapter(this, elementList);
        listView.setAdapter(myListAdapter);
        linearLayout.addView(listView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0,1));
        setContentView(linearLayout);
    }

    private boolean getCurrencyFromBOT() {

        final boolean[] completeProcess = {false};

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                final StringBuilder builder = new StringBuilder();

                try {
                    //台灣銀行牌告匯率
                    Document doc = Jsoup.connect("https://rate.bot.com.tw/xrt?Lang=zh-TW").get();
                    String title = doc.title(); //取得網頁標題
                    Elements tds = doc.select("td"); //選擇網頁中td標籤中的內容
                    String currency_country = null;
                    String currency_rate_buy = null;
                    String currency_rate_sell = null;
                    String[] currency_country_token = null;

                    //builder.append(title).append("\n");

                    //for(int i = 0; i < tds.size(); i=i+11){
                    int i = 0;  //currency_USD 美金
                    currency_country = tds.get(i).text();
                    currency_country_token = currency_country.split(" "); //字串切割
                    currency_rate_buy = tds.get((i + 1)).text();
                    currency_rate_sell = tds.get((i + 2)).text();
                    currency_USD = (Double.parseDouble(currency_rate_buy)
                            + Double.parseDouble(currency_rate_sell)) / 2;
                    builder.append(currency_country_token[0])
                            .append("\t").append(currency_USD)
                            .append("\n");
                    currencyValue[0] = df.format(currency_USD);

                    int j = 22; //currency_GBP 英鎊
                    currency_country = tds.get(j).text();
                    currency_country_token = currency_country.split(" "); //字串切割
                    currency_rate_buy = tds.get((j + 1)).text();
                    currency_rate_sell = tds.get((j + 2)).text();
                    currency_GBP = (Double.parseDouble(currency_rate_buy)
                            + Double.parseDouble(currency_rate_sell)) / 2;
                    builder.append(currency_country_token[0])
                            .append("\t").append(currency_GBP)
                            .append("\n");
                    currencyValue[1] = df.format(currency_GBP);

                    int k = 44; //currency_CAD 加幣
                    currency_country = tds.get(k).text();
                    currency_country_token = currency_country.split(" "); //字串切割
                    currency_rate_buy = tds.get((k + 1)).text();
                    currency_rate_sell = tds.get((k + 2)).text();
                    currency_CAD = (Double.parseDouble(currency_rate_buy)
                            + Double.parseDouble(currency_rate_sell)) / 2;
                    builder.append(currency_country_token[0])
                            .append("\t").append(currency_CAD)
                            .append("\n");
                    currencyValue[2] = df.format(currency_CAD);


                    int l = 165; //currency_KRW 韓元
                    currency_country = tds.get(l).text();
                    currency_country_token = currency_country.split(" "); //字串切割
                    currency_rate_buy = tds.get((l + 1)).text();
                    currency_rate_sell = tds.get((l + 2)).text();
                    currency_KRW = (Double.parseDouble(currency_rate_buy)
                            + Double.parseDouble(currency_rate_sell)) / 2;
                    builder.append(currency_country_token[0])
                            .append("\t").append(currency_KRW)
                            .append("\n");
                    currencyValue[3] = df.format(currency_KRW);


                    int m = 77; //currency_JPY 日圓
                    currency_country = tds.get(m).text();
                    currency_country_token = currency_country.split(" "); //字串切割
                    currency_rate_buy = tds.get((m + 1)).text();
                    currency_rate_sell = tds.get((m + 2)).text();
                    currency_JPY = (Double.parseDouble(currency_rate_buy)
                            + Double.parseDouble(currency_rate_sell)) / 2;
                    builder.append(currency_country_token[0])
                            .append("\t").append(currency_JPY)
                            .append("\n");
                    currencyValue[4] = df.format(currency_JPY);

                    completeProcess[0] = true;


                } catch (IOException e) {
                    builder.append("Error : ").append(e.getMessage()).append("\n");
                }

            }
        });

        t.start();
        try {
            t.join();
        } catch (InterruptedException e) { e.printStackTrace(); }

        if(completeProcess[0] == true){
            return true;
        }
        else{
            return false;
        }
    }//getCurrencyFromBOT() 函式結束
}
