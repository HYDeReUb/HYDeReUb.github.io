package com.example.mycurrency;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyListAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<MyListElement> elementList;

    MyListAdapter(Activity activity, ArrayList<MyListElement> elementList){
        this.activity = activity;
        this.elementList = elementList;
    }
    @Override
    public int getCount() {
        return elementList.size();
    }

    @Override
    public Object getItem(int i) {
        return elementList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = activity.getLayoutInflater().inflate(R.layout.layout_mylist_element, null);
        ImageView img = (ImageView)view.findViewById(R.id.imageView);
        TextView textViewTitle = (TextView)view.findViewById(R.id.textViewLarge);
        TextView textViewValue = (TextView)view.findViewById(R.id.textViewValue);
        img.setImageResource(elementList.get(i).getCountryIcon());
        String currencyKeyLoad = elementList.get(i).getCurrencyKeyLoad();
        String currencyValue = elementList.get(i).getCurrencyValue();
        textViewTitle.setText(currencyKeyLoad);
        textViewValue.setText(currencyValue);
        return view;
    }
}
