package com.example.ksuie.mybmi_final;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle("Page 2");

        Bundle bundle=getIntent().getExtras();
        String name=bundle.getString("key1","Default");
        TextView bmi2=findViewById(R.id.bmi2);

        double bmi_d = Double.parseDouble(name);
        TextView z=findViewById(R.id.z);
        TextView a=findViewById(R.id.button2);
        Resources res = this.getResources();
        ConstraintLayout w =findViewById(R.id.w);
        Drawable drawable;

        if(bmi_d < 1){
            a.setEnabled(false);
            z.setText("");
            a.setText("接受鯊鯊的制裁八");
            drawable = res.getDrawable(R.drawable.a);
            w.setBackground(drawable);
            moveTaskToBack(true);
        }
        else if(bmi_d > 150){
            a.setEnabled(false);
            z.setText("");
            a.setText("接受鯊鯊的制裁八");
                drawable = res.getDrawable(R.drawable.a);
                w.setBackground(drawable);
            moveTaskToBack(true);
            }
        else if(bmi_d<18.5&&bmi_d>0){
            z.setText("過輕");
            bmi2.setText("BMI="+name);
            drawable = res.getDrawable(R.drawable.bmi1);
            w.setBackground(drawable);
        }
        else if(bmi_d<24 && bmi_d>=18.5){
            z.setText("正常");
            bmi2.setText("BMI="+name);
            drawable = res.getDrawable(R.drawable.bmi2);
            w.setBackground(drawable);
        }
        else if(bmi_d<27 && bmi_d>=24){
            z.setText("過重");
            bmi2.setText("BMI="+name);
            drawable = res.getDrawable(R.drawable.bmi3);
            w.setBackground(drawable);
        }
        else if(bmi_d<30 && bmi_d>=27){
            z.setText("輕度肥胖");
            bmi2.setText("BMI="+name);
            drawable = res.getDrawable(R.drawable.bmi4);
            w.setBackground(drawable);
        }
        else if(bmi_d<35 && bmi_d>=30){
            z.setText("中度肥胖");
            bmi2.setText("BMI="+name);
            drawable = res.getDrawable(R.drawable.bmi5);
            w.setBackground(drawable);
        }
        else if(bmi_d>=35){
            z.setText("重度肥胖");
            bmi2.setText("BMI="+name);
            drawable = res.getDrawable(R.drawable.bmi6);
            w.setBackground(drawable);
        }




        Button btn_to_page1=(Button)findViewById(R.id.button2);
        btn_to_page1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent= new Intent();
                intent.setClass(Main2Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
