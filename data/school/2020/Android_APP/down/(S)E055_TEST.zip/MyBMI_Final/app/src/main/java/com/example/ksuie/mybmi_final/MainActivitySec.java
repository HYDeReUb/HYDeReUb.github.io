package com.example.ksuie.mybmi_final;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivitySec extends AppCompatActivity {

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secpage);

        setTitle("Page 2");

        // getting the bundle back from the android
        Bundle bundle = getIntent().getExtras();

        // getting the string back
        String XRI1 = bundle.getString("key1", "Default");
        String XRI2 = bundle.getString("key2", "Default");
        TextView display = findViewById(R.id.Target1);
        display.setText(XRI1);
        TextView TargetX = findViewById(R.id.Target2);
        TargetX.setText(XRI2);


        Button btn_to_page1 = (Button) findViewById(R.id.return1);
           btn_to_page1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivitySec.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
