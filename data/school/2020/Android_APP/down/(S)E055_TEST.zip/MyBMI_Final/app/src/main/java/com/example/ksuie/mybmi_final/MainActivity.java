package com.example.ksuie.mybmi_final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            setTitle("Page 1"); //設定頁面標題

            Button btn2 = (Button)findViewById(R.id.sendP2);

            btn2.setOnClickListener(new View.OnClickListener() {  //將button綁定ClickListener
                @Override
                public void onClick(View v) {

                    String XRI1 = STRG(); //呼叫副函示，取得BMI值
                    String XRI2 = STRX();


                    Intent intent = new Intent(); //準備換頁用的Intent物件
                    intent.setClass(MainActivity.this, MainActivitySec.class); //設定起始頁面class檔，終止頁面class檔

                    // crating a bundle object
                    Bundle bundle = new Bundle(); //建立Bundle物件，用來存放要傳送到第二頁的值

                    // storing the string value in the bundle which is mapped to key
                    bundle.putString("key1", XRI1); //將要傳送到第二頁的字串BMI_s 放入Bundle物件中
                    bundle.putString("key2", XRI2);
                    // passing the bundle into the intent
                    intent.putExtras(bundle); //將bundle放入intent中，準備換頁

                    startActivity(intent); //開始換頁
                }

            });
        }

    public String STRG() {
        EditText class2 = findViewById(R.id.classEdit);
        EditText classNum1  = findViewById(R.id.classNumEdit);
        EditText name1 = findViewById(R.id.nameEdit);
        EditText em1 = findViewById(R.id.emEdit);
        EditText pNum1  = findViewById(R.id.pNumEdit);

        String class1s = class2.getText().toString();
        String classNum1s = classNum1.getText().toString();
        String name1s = name1.getText().toString();
        String em1s = em1.getText().toString();
        String pNum1s = pNum1.getText().toString();

        return class1s + "\n" + classNum1s + "\n" + name1s + "\n" + em1s + "\n" + pNum1s;
        }

    public String STRX() {

        EditText TEXT = findViewById(R.id.reportEdit);
        String TEXT1s = TEXT.getText().toString();
        return TEXT1s;
    }
}