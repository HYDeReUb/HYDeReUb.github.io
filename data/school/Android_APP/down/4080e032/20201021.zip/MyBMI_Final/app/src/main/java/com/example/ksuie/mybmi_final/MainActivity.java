package com.example.ksuie.mybmi_final;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    ImageView  imageView;
    DecimalFormat df=new DecimalFormat("##.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayName(View view){
        EditText x=findViewById(R.id.x);
        EditText y=findViewById(R.id.y);

        String x_s=x.getText().toString();
        String y_s=y.getText().toString();

        double x_d=Double.parseDouble(x_s);
        double y_d=Double.parseDouble(y_s);

        double bmi_d=y_d/((x_d/100)*(x_d/100));
        TextView display=findViewById(R.id.bmi);
        TextView z=findViewById(R.id.z);
        imageView= findViewById(R.id.imageView);
        display.setText("BMI="+df.format(bmi_d));
        if(bmi_d<18.5){
            z.setText("過輕");
            imageView.setImageResource(R.drawable.bmi1);
        }
        else if(bmi_d<24 && bmi_d>=18.5){
            z.setText("正常");
            imageView.setImageResource(R.drawable.bmi2);
        }
        else if(bmi_d<27 && bmi_d>=24){
            z.setText("過重");
            imageView.setImageResource(R.drawable.bmi3);
        }
        else if(bmi_d<30 && bmi_d>=27){
            z.setText("輕度肥胖");
            imageView.setImageResource(R.drawable.bmi4);
        }
        else if(bmi_d<35 && bmi_d>=30){
            z.setText("中度肥胖");
            imageView.setImageResource(R.drawable.bmi5);
        }
        else if(bmi_d>=35){
            z.setText("重度肥胖");
            imageView.setImageResource(R.drawable.bmi6);
        }
    }
}
