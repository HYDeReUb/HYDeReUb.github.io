package com.example.ksuie.mybmi_final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    ImageView  imageView;
    DecimalFormat df=new DecimalFormat("##.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Page 1");

        Button btn_to_page2=(Button)findViewById(R.id.button);
        btn_to_page2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent= new Intent();
                intent.setClass(MainActivity.this,Main2Activity.class);
                Bundle bundle =new Bundle();
                bundle.putString("key1", String.valueOf(displayName()));
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
    public double displayName(){
        EditText x=findViewById(R.id.x);
        EditText y=findViewById(R.id.y);

        String x_s=x.getText().toString();
        String y_s=y.getText().toString();

        double x_d=Double.parseDouble(x_s);
        double y_d=Double.parseDouble(y_s);

        double bmi_d=y_d/((x_d/100)*(x_d/100));
        return bmi_d;

    }
}
