package com.example.ksuie.mybmi_final;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle("Page 2");

        Bundle bundle=getIntent().getExtras();
        String name=bundle.getString("key1","Default");
        TextView bmi2=findViewById(R.id.bmi2);
        bmi2.setText("BMI="+name);
        double bmi_d = Double.parseDouble(name);
        TextView z=findViewById(R.id.z);
        ImageView imageView= findViewById(R.id.imageView);
        if(bmi_d<18.5){
            z.setText("過輕");
            imageView.setImageResource(R.drawable.bmi1);
        }
        else if(bmi_d<24 && bmi_d>=18.5){
            z.setText("正常");
            imageView.setImageResource(R.drawable.bmi2);
        }
        else if(bmi_d<27 && bmi_d>=24){
            z.setText("過重");
            imageView.setImageResource(R.drawable.bmi3);
        }
        else if(bmi_d<30 && bmi_d>=27){
            z.setText("輕度肥胖");
            imageView.setImageResource(R.drawable.bmi4);
        }
        else if(bmi_d<35 && bmi_d>=30){
            z.setText("中度肥胖");
            imageView.setImageResource(R.drawable.bmi5);
        }
        else if(bmi_d>=35){
            z.setText("重度肥胖");
            imageView.setImageResource(R.drawable.bmi6);
        }



        Button btn_to_page1=(Button)findViewById(R.id.button2);
        btn_to_page1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent= new Intent();
                intent.setClass(Main2Activity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
