package com.example.ksuie.mybmi_final;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    DecimalFormat df = new DecimalFormat("##.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayName(View view){

    }
    public void BMI(View view) {
        EditText height = findViewById(R.id.height);
        EditText weight = findViewById(R.id.weight);

        String height_s = height.getText().toString();
        String weight_s = weight.getText().toString();

        double height_d = Double.parseDouble(height_s);
        double weight_d = Double.parseDouble(weight_s);

        double bmi_result = weight_d / ((height_d / 100) * (height_d / 100));

        TextView display = findViewById(R.id.textView4);
        display.setText("BMI= " + df.format(bmi_result));
        TextView textheal = findViewById(R.id.textView5);
        if (bmi_result < 18.5) {
            textheal.setText("Low");
        } else if (bmi_result < 24 && bmi_result >= 18.5) {
            textheal.setText("Good");
        } else if (bmi_result < 27 && bmi_result >= 24) {
            textheal.setText("little High");
        } else if (bmi_result < 30 && bmi_result >= 27) {
            textheal.setText("High");
        } else if (bmi_result < 35 && bmi_result >= 30) {
            textheal.setText("Very High");
        } else if (bmi_result >= 35) {
            textheal.setText("Extreme High");
        }
    }
     public void Clean(View view){
     TextView textcln1=findViewById(R.id.textView5);
     TextView textcln2=findViewById(R.id.textView4);
     EditText textcln3=findViewById(R.id.height);
     EditText textcln4=findViewById(R.id.weight);
      textcln1.setText("");
      textcln2.setText("");
      textcln3.setText("");
      textcln4.setText("");
        }

}
