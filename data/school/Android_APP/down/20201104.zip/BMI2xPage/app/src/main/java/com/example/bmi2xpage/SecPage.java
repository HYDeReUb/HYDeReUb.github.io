package com.example.bmi2xpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_page);

        setTitle("BMI Page 2");

        // getting the bundle back from the android
        Bundle bundle = getIntent().getExtras();

        // getting the string back
        String BMI = bundle.getString("key1", "Default");

        TextView display = findViewById(R.id.display2);
        display.setText(BMI);


        Button btn_to_page1 = (Button) findViewById(R.id.back);

        btn_to_page1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(SecPage.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}