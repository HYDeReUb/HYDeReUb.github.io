package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    DecimalFormat df = new DecimalFormat("##.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void BMI(View view){
        EditText height = findViewById(R.id.height);
        EditText weight = findViewById(R.id.weight);

        String height_s = height.getText().toString();
        String weight_s = weight.getText().toString();

        double height_d = Double.parseDouble(height_s);// 取得身高輸入值
        double weight_d = Double.parseDouble(weight_s);// 取得體重輸入值

        double bmi_result = weight_d/((height_d/100)*(height_d/100)); // BMI值計算結果

        TextView display = findViewById(R.id.display);
        display.setText(df.format(bmi_result));

        TextView display2 = (TextView)findViewById(R.id.display2);// 取得顯示診斷物件
        // 診斷結果 顯示
        if (bmi_result<18.5)
            display2.setText("體重過輕");
        else if (18.5 <= bmi_result && bmi_result< 24)
            display2.setText("正常範圍");
        else if (24 <=bmi_result && bmi_result < 27)
            display2.setText("過    重");
        else if (27 <=bmi_result && bmi_result < 30)
            display2.setText("輕度肥胖");
        else if (30 <= bmi_result && bmi_result < 35)
            display2.setText("中度肥胖");
        else if (bmi_result >= 35)
            display2.setText("重度肥胖");
    }
}