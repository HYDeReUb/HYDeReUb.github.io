package com.example.page_change;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Page 1");

        Button btn_to_page2 = (Button) findViewById(R.id.button);

        btn_to_page2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, MainActivity2.class);

                // crating a bundle object
                Bundle bundle = new Bundle();

                EditText name = findViewById(R.id.inputName);
                String name_s = name.getText().toString();

                // storing the string value in the bundle which is mapped to key
                bundle.putString("key1", name_s);

                // passing the bundle into the intent
                intent.putExtras(bundle);

                startActivity(intent);
            }
        });
    }//end of conCreate
}