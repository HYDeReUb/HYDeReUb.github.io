package com.example.page_change;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        setTitle("Page 2");

        // getting the bundle back from the android
        Bundle bundle = getIntent().getExtras();

        // getting the string back
        String TextView = bundle.getString("key1", "Default");

        TextView display = findViewById(R.id.display2);
        display.setText(TextView);


        Button btn_to_page1 = (Button) findViewById(R.id.button2);

        btn_to_page1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}