package com.example.bmi_app_10_24;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    DecimalFormat df = new DecimalFormat("##.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("BMI Page 1");

        Button btn_to_page2 = (Button) findViewById(R.id.button3);

        btn_to_page2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, MainActivity2.class);

                // crating a bundle object
                Bundle bundle = new Bundle();

                EditText name = findViewById(R.id.inputname);
                String name_s1 = name.getText().toString();

                EditText height = findViewById(R.id.height);
                EditText weight = findViewById(R.id.weight);
                String height_s = height.getText().toString();
                String weight_s = weight.getText().toString();
                Double height_d = Double.parseDouble(height_s);
                Double weight_d = Double.parseDouble(weight_s);
                Double bmi_result = weight_d/((height_d/100)*(height_d/100));

                TextView displaygo = findViewById(R.id.display2);
                String result = displaygo.getText().toString();
                if (bmi_result<18.5)
                    displaygo.setText("體重過輕");
                else if(18.5<=bmi_result && bmi_result<24)
                    displaygo.setText("正常範圍");
                else if(24<=bmi_result && bmi_result<27)
                    displaygo.setText("過重");
                else if(27<=bmi_result && bmi_result<30)
                    displaygo.setText("輕度肥胖");
                else if(30<=bmi_result && bmi_result<35)
                    displaygo.setText("中度肥胖");
                else if(bmi_result>=35)
                    displaygo.setText("重度肥胖");

                // storing the string value in the bundle which is mapped to key
                bundle.putString("key1", "使用者："+ name_s1);
                bundle.putString("key2", "BMI："+ df.format(bmi_result));
                bundle.putString("key3", "診斷："+ result);
                // passing the bundle into the intent
                intent.putExtras(bundle);

                startActivity(intent);
            }
        });
    }//end of conCreate

    public void BMI1(View view){
        EditText name = findViewById(R.id.inputname);
        EditText height = findViewById(R.id.height);
        EditText weight = findViewById(R.id.weight);

        String name_s = name.getText().toString();
        String height_s = height.getText().toString();
        String weight_s = weight.getText().toString();

        Double height_d = Double.parseDouble(height_s);
        Double weight_d = Double.parseDouble(weight_s);
        Double bmi_result = weight_d/((height_d/100)*(height_d/100));

        TextView display = findViewById(R.id.display);
        TextView display1 = findViewById(R.id.display1);
        TextView display2 = findViewById(R.id.display2);

        display.setText(name_s);

        display1.setText(df.format(bmi_result));

        if (bmi_result<18.5)
            display2.setText("體重過輕");
        else if(18.5<=bmi_result && bmi_result<24)
            display2.setText("正常範圍");
        else if(24<=bmi_result && bmi_result<27)
            display2.setText("過重");
        else if(27<=bmi_result && bmi_result<30)
            display2.setText("輕度肥胖");
        else if(30<=bmi_result && bmi_result<35)
            display2.setText("中度肥胖");
        else if(bmi_result>=35)
            display2.setText("重度肥胖");
    }
}