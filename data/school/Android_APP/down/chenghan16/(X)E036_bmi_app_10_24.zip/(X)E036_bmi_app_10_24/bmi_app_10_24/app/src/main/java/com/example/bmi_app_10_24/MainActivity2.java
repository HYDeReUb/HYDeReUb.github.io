package com.example.bmi_app_10_24;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        setTitle("BMI Page 2");

        // getting the bundle back from the android
        Bundle bundle = getIntent().getExtras();

        // getting the string back
        String BMI = bundle.getString("key1", "Default");
        String BMI1 = bundle.getString("key2", "Default");
        String BMI2 = bundle.getString("key3", "Default");

        TextView display3 = findViewById(R.id.display3);
        display3.setText(BMI);

        TextView display4 = findViewById(R.id.display4);
        display4.setText(BMI1);

        TextView display5 = findViewById(R.id.display5);
        display5.setText(BMI2);

        Button btn_to_page1 = (Button) findViewById(R.id.button2);

        btn_to_page1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}