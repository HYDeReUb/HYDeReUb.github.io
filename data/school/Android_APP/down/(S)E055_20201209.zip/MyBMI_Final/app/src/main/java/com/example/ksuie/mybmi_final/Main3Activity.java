package com.example.ksuie.mybmi_final;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Main3Activity extends AppCompatActivity {

    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        webview = (WebView)findViewById(R.id.companyWebView);
        webview.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webview.getSettings();
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(true);

        String companyName_s = getIntent().getStringExtra("companyName");
        String companyURL_s = getIntent().getStringExtra("companyURL");
        getSupportActionBar().setTitle(companyName_s);
        webview.loadUrl(companyURL_s);

    }
}