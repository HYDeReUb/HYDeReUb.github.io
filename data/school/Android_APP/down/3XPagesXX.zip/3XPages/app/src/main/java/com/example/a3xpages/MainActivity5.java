package com.example.a3xpages;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {
    String[] companyNames;
    String[] companyURLs;
    LinearLayout linearLayout;
    ListView listView;
    ArrayList<String> companyList;
    ArrayList<String> urlList;
    ArrayList<MyListItem> itemList
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}