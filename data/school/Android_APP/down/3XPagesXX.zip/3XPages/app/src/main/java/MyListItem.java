public class MyListItem {
    private int img;

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getCompanyNames() {
        return companyNames;
    }

    public void setCompanyNames(String companyNames) {
        this.companyNames = companyNames;
    }

    public String getCompanyURLs() {
        return companyURLs;
    }

    public void setCompanyURLs(String companyURLs) {
        this.companyURLs = companyURLs;
    }

    private String companyNames;
    private String companyURLs;
}
