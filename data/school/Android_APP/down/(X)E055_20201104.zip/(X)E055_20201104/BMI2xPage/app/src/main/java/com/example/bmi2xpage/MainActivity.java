package com.example.bmi2xpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    DecimalFormat df = new DecimalFormat("###0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("BMI Page 1");

        Button btn_to_page2 = (Button) findViewById(R.id.calc);

        btn_to_page2.setOnClickListener(new View.OnClickListener() {  //將button綁定ClickListener
            @Override
            public void onClick(View v) {

                String BMI_s = BMI(); //呼叫副函示，取得BMI值
                if (BMI_s != null) { //判斷BMI_s是否為null

                    Intent intent = new Intent(); //準備換頁用的Intent物件
                    intent.setClass(MainActivity.this, SecPage.class); //設定起始頁面class檔，終止頁面class檔

                    // crating a bundle object
                    Bundle bundle = new Bundle(); //建立Bundle物件，用來存放要傳送到第二頁的值

                    // storing the string value in the bundle which is mapped to key
                    bundle.putString("key1", BMI_s); //將要傳送到第二頁的字串BMI_s 放入Bundle物件中

                    // passing the bundle into the intent
                    intent.putExtras(bundle); //將bundle放入intent中，準備換頁

                    startActivity(intent); //開始換頁
                }
            }

            public String BMI() {
                EditText name = findViewById(R.id.editTextTextPersonName);
                String name_s = name.getText().toString();

                EditText height = findViewById(R.id.editTextNumber); //連結height
                EditText weight = findViewById(R.id.editTextNumber2); //連結weight

                String height_s = height.getText().toString(); //取得輸入的身高(字串)
                String weight_s = weight.getText().toString(); //取得輸入的體重(字串)


                if (height_s.equals("") || weight_s.equals("")) {
                    return "錯誤的輸入!!(身高及體重未輸入齊全)"; // 如果身高或體重有任一個是空字串，回傳null
                }
                else {
                    double height_d = Double.parseDouble(height_s);  //將輸入的身高(字串)轉換為數字double
                    double weight_d = Double.parseDouble(weight_s); //將輸入的體重(字串)轉換為數字double

                    height_d = height_d / 100;
                    double bmi = weight_d / (height_d * height_d); //計算BMI，存放在bmi變數中

                    if ((height_d > 3) && (weight_d > 750)) {
                        return "錯誤的輸入!!(身高>300cm)、(體重>750kg)";
                    }
                    else if (height_d > 3) {
                        return "錯誤的輸入!!(身高>300cm)";
                    }
                    else if (weight_d > 750) {
                        return "錯誤的輸入!!(體重>750kg)";
                    }
                    else if (bmi < 1) {
                        return "錯誤的輸入!!(BMI<1)";
                    }
                    else if (bmi > 150) {
                        return "錯誤的輸入!!(BMI>150)";
                    }
                    else{return "您好" + name_s + "，您的BMI是" + df.format(bmi);} //回傳BMI結果  利用df.format(bmi)取小數點以下2位
                }

                }


        });

        }
    }